// let openShopping = document.querySelector(".shopping");
// let closeShopping = document.querySelector(".closeShopping");
let list = document.querySelector(".list");
let listCard = document.querySelector(".listCard");
let body = document.querySelector(".body");
let total = document.querySelector(".total");
let quantity = document.querySelector(".quantity");
let productDetailsView = document.getElementById("productDetailsView");
let categoryBox = document.getElementById("category-box");
let categoryLabel = document.getElementById("category-label");
let productTotal = document.getElementById("product-total");
// openShopping.addEventListener("click", () => {
//   document.body.classList.add("active");
// });
// closeShopping.addEventListener("click", () => {
//   document.body.classList.remove("active");
// });

// let addProductLists = [];

(async () => {
  categories.forEach((cate) => {
    categoryBox.innerHTML += `
    <button class="category-btn category-btn-${cate.id}" onclick="changeCategory(${cate.id})">${cate.name}</button>
    `;
  });
})();

function changeCategory(id) {
  categoryLabel.innerText = categories.find(
    (category) => category.id == id
  ).name;
  list.innerHTML = null;
  initApp(id);
}

function initApp(categoryId = "") {
  let productsArr = [];
  if (categoryId) {
    productsArr = products.filter(
      (product) => product.categoryId === categoryId
    );
  } else {
    productsArr = products;
  }
  productTotal.innerText = `(${productsArr.length})`;
  productsArr.forEach((value, key) => {
    console.log(value);
    let newDiv = document.createElement("div");
    newDiv.classList.add("item");
    newDiv.innerHTML = `
        <img src="img/newproduct/${value.image}"/>
        <div class="title">${cutString(value.name, 15)}</div>
        <div class="price">${value.price.toLocaleString()}</div>
        <button style="margin-bottom: 4px;"  onClick="viewDetails(${key})" > View </button> 
        <button onclick="addToCard(${value.id})">Add To Cart</button>`;
    list.appendChild(newDiv);
  });
}
initApp();
// function addToCard(key) {
//   if (addProductLists[key] == null) {
//     addProductLists[key] = products[key];
//     addProductLists[key].quantity = 1;
//   }
//   reloadCard();
// }

function addToCard(productId) {
  let carts = JSON.parse(localStorage.getItem("carts"));
  let alreadyExist = carts?.find((cart) => cart?.id === productId);
  let product = products.find((product) => product.id === productId);
  if (alreadyExist == undefined) {
    let currentProduct = { ...product, quantity: 1 };
    if (carts !== null) {
      localStorage.setItem("carts", JSON.stringify([...carts, currentProduct]));
    } else {
      localStorage.setItem("carts", JSON.stringify([currentProduct]));
    }
    showQty();
  }
}

function reloadCard() {
  listCard.innerHTML = "";
  let count = 0;
  let totalPrice = 0;
  addProductLists.forEach((value, key) => {
    totalPrice = totalPrice + value.price;
    count = count + value.quantity;

    if (value != null) {
      let newDiv = document.createElement("li");
      newDiv.innerHTML = `<div><img src="img/newproduct/${value.image}"/></div>
            <div>${value.name}</div>
            <div>${value.price.toLocaleString()}</div>
            <div>
            <button onclick="changeQuantity(${key},${
        value.quantity - 1
      })">-</button>
            <div class="count">${value.quantity}</div>
            <button onclick="changeQuantity(${key},${
        value.quantity + 1
      })">+</button>
            </div>`;
      listCard.appendChild(newDiv);
    }
  });
  total.innerText = totalPrice.toLocaleString();
  quantity.innerText = count;
}
function changeQuantity(key, quantity) {
  if (quantity == 0) {
    delete addProductLists[key];
  } else {
    addProductLists[key].quantity = quantity;
    addProductLists[key].price = quantity * products[key].price;
  }
  reloadCard();
}

const viewDetails = (index) => {
  const product = products[index];
  const productName = document.getElementById("productName");
  const productPrice = document.getElementById("productPrice");
  const productId = document.getElementById("productIndex");
  const productImg = document.getElementById("productImg");
  productName.innerHTML = product.name;
  productPrice.innerHTML = product.price;
  productId.innerHTML = index;
  productImg.src = `img/newproduct/${product.image}`;
  productDetailsView.showModal();
};

function cutString(text, total) {
  const textString = String(text);
  return textString.length > total
    ? textString.slice(0, total) + " ..."
    : textString;
}
